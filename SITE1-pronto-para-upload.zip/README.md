# SITE1 — Acessórios de Princesa

Site estático responsivo para a loja Acessórios de Princesa.

Antes de publicar: adicione o logo real como `logo.png` e troque o domínio do sitemap/robots pelo domínio definitivo.
