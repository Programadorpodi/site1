# SITE2 — Montador de PC

Protótipo 2D de um configurador de PCs feito com HTML, CSS e JavaScript puro.

## Recursos
- Seleção de CPU, placa-mãe, RAM, GPU, SSD, fonte, gabinete e cooler.
- Visualização 2D que muda conforme as peças são escolhidas.
- Cálculo automático do preço.
- Orçamento máximo.
- Alertas básicos de compatibilidade (socket, DDR e fonte).
- Salvar configuração no navegador com localStorage.
- Copiar um resumo da configuração.
- Layout responsivo para celular.

## Como abrir
Abra `index.html` no navegador. Não precisa de banco de dados nem servidor para esta versão.

## Próximas evoluções
1. Adicionar catálogo real de peças.
2. Colocar imagens PNG reais de cada componente.
3. Criar filtros por marca, preço e desempenho.
4. Adicionar consumo de energia e dimensões.
5. Criar sistema de pontuação/desempenho.
6. Integrar preços reais por API ou catálogo próprio.
7. Publicar no Vercel.
