const products = {
  cpu: [
    {id:"r5-5600", name:"Ryzen 5 5600", price:799, meta:"6c/12t • AM4"},
    {id:"r5-7600", name:"Ryzen 5 7600", price:1199, meta:"6c/12t • AM5"},
    {id:"r7-7800", name:"Ryzen 7 7800X3D", price:2199, meta:"8c/16t • AM5"},
  ],
  motherboard: [
    {id:"a520", name:"A520M", price:399, meta:"AM4 • DDR4"},
    {id:"b650", name:"B650M", price:899, meta:"AM5 • DDR5"},
    {id:"x670", name:"X670", price:1399, meta:"AM5 • DDR5"},
  ],
  ram: [
    {id:"16-ddr4", name:"16 GB (2×8) DDR4", price:299, meta:"3200 MHz"},
    {id:"32-ddr4", name:"32 GB (2×16) DDR4", price:529, meta:"3200 MHz"},
    {id:"32-ddr5", name:"32 GB (2×16) DDR5", price:699, meta:"6000 MHz"},
  ],
  gpu: [
    {id:"rx7600", name:"Radeon RX 7600", price:1699, meta:"8 GB"},
    {id:"rtx4060", name:"GeForce RTX 4060", price:1899, meta:"8 GB"},
    {id:"rtx4070s", name:"GeForce RTX 4070 Super", price:4299, meta:"12 GB"},
  ],
  storage: [
    {id:"ssd500", name:"SSD NVMe 500 GB", price:249, meta:"PCIe 3.0"},
    {id:"ssd1tb", name:"SSD NVMe 1 TB", price:449, meta:"PCIe 4.0"},
    {id:"ssd2tb", name:"SSD NVMe 2 TB", price:799, meta:"PCIe 4.0"},
  ],
  psu: [
    {id:"550", name:"Fonte 550 W 80+ Bronze", price:329, meta:"550 W"},
    {id:"650", name:"Fonte 650 W 80+ Bronze", price:399, meta:"650 W"},
    {id:"750", name:"Fonte 750 W 80+ Gold", price:699, meta:"750 W"},
  ],
  case: [
    {id:"air", name:"Gabinete AirFlow", price:299, meta:"ATX • 3 fans"},
    {id:"glass", name:"Gabinete Glass RGB", price:449, meta:"ATX • 4 fans"},
    {id:"tower", name:"Gabinete Tower Pro", price:699, meta:"ATX • 6 fans"},
  ],
  cooler: [
    {id:"box", name:"Cooler Box", price:0, meta:"Incluso"},
    {id:"tower", name:"Air Cooler Tower", price:179, meta:"120 mm"},
    {id:"water", name:"Water Cooler 240 mm", price:399, meta:"AIO"},
  ]
};

const labels = {cpu:"Processador", motherboard:"Placa-mãe", ram:"Memória RAM", gpu:"Placa de vídeo", storage:"Armazenamento", psu:"Fonte", case:"Gabinete", cooler:"Cooler"};
const icons = {cpu:"🧠",motherboard:"🟩",ram:"🧩",gpu:"🎮",storage:"💾",psu:"⚡",case:"🖥️",cooler:"❄️"};
const state = {budget:6000, selected:{}};
let activeCategory = "cpu";

const categories = document.querySelector("#categories");
const optionsPanel = document.querySelector("#optionsPanel");

function money(n){ return n.toLocaleString("pt-BR",{style:"currency",currency:"BRL"}); }
function total(){ return Object.values(state.selected).reduce((s,p)=>s+(p?.price||0),0); }

function renderCategories(){
  categories.innerHTML = Object.keys(products).map(key=>`
    <button class="cat-btn ${key===activeCategory?"active":""}" data-cat="${key}">
      <span class="cat-icon">${icons[key]}</span><span>${labels[key]}</span>
    </button>`).join("");
  categories.querySelectorAll(".cat-btn").forEach(b=>b.onclick=()=>{activeCategory=b.dataset.cat;renderCategories();renderOptions();});
}

function renderOptions(){
  const list=products[activeCategory];
  optionsPanel.innerHTML=`
    <div class="options-title"><h3>${icons[activeCategory]} ${labels[activeCategory]}</h3><span>Escolha uma opção</span></div>
    <div class="options">${list.map(p=>`
      <button class="option ${state.selected[activeCategory]?.id===p.id?"selected":""}" data-id="${p.id}">
        <span class="name">${p.name}</span>
        <span class="meta"><span>${p.meta}</span><b>${money(p.price)}</b></span>
      </button>`).join("")}</div>`;
  optionsPanel.querySelectorAll(".option").forEach(b=>b.onclick=()=>{
    state.selected[activeCategory]=list.find(p=>p.id===b.dataset.id);
    renderOptions(); renderSummary(); updateVisual(); updateCompatibility();
  });
}

function renderSummary(){
  const entries=Object.entries(state.selected);
  document.querySelector("#selectedList").innerHTML=entries.length ? entries.map(([k,p])=>`
    <div class="selected-item"><div><span>${labels[k]}</span><b>${p.name}</b></div><strong>${money(p.price)}</strong></div>`).join("") : `<p class="empty">Nenhuma peça escolhida ainda.<br>Comece pelo processador.</p>`;
  document.querySelector("#total").textContent=money(total());
  updateBudget();
}

function updateBudget(){
  const t=total(), b=Number(state.budget)||0, remaining=b-t;
  document.querySelector("#budgetBar").style.width=b ? Math.min(100,(t/b)*100)+"%" : "0%";
  const el=document.querySelector("#budgetText");
  el.textContent=remaining>=0 ? `Você ainda tem ${money(remaining)}` : `Você ultrapassou o orçamento em ${money(Math.abs(remaining))}`;
  el.style.color=remaining>=0?"":"#ff8196";
}

function updateVisual(){
  const s=state.selected;
  document.querySelector("#visualCpu").textContent=s.cpu ? s.cpu.name.replace("Ryzen ","R").replace("GeForce ","RTX ") : "CPU";
  const ramSlots=document.querySelectorAll("#visualRam1,#visualRam2,#visualRam3,#visualRam4");
  const ram=s.ram?.name||"";
  ramSlots.forEach((x,i)=>x.style.display=ram ? (ram.includes("32")||i<2 ? "block":"none"):"none");
  const gpu=document.querySelector("#visualGpu");
  gpu.innerHTML=s.gpu ? `<b>${s.gpu.name.replace("GeForce ","").replace("Radeon ","")}</b><small>${s.gpu.meta}</small>` : `<b>GPU</b><small>Escolha uma placa de vídeo</small>`;
  document.querySelector("#visualStorage").textContent=s.storage?.name.split(" ").slice(-2).join(" ")||"SSD";
  document.querySelector("#visualCooler").textContent=s.cooler?.name==="Cooler Box"?"BOX":"COOLER";
  document.querySelector("#pcName").textContent=s.cpu ? `${s.cpu.name} + ${s.gpu?.name||"GPU não escolhida"}` : "Seu PC personalizado";
  document.querySelector("#pcSub").textContent=s.case?.name || "Escolha suas peças ao lado";
}

function updateCompatibility(){
  const s=state.selected, badge=document.querySelector("#statusBadge");
  let type="good", msg="● Compatibilidade básica OK";
  if(s.cpu && s.motherboard){
    const am4=s.cpu.meta.includes("AM4"), am5=s.cpu.meta.includes("AM5");
    const mb4=s.motherboard.meta.includes("AM4"), mb5=s.motherboard.meta.includes("AM5");
    if((am4&&!mb4)||(am5&&!mb5)){type="bad";msg="● CPU e placa-mãe incompatíveis";}
  }
  if(type==="good" && s.motherboard && s.ram){
    const ddr4=s.motherboard.meta.includes("DDR4"), ddr5=s.motherboard.meta.includes("DDR5");
    if((ddr4&&s.ram.meta.includes("DDR5"))||(ddr5&&s.ram.meta.includes("DDR4"))){type="bad";msg="● RAM incompatível com a placa-mãe";}
  }
  const watts=s.psu?.price===699?750:s.psu?.price===399?650:s.psu?.price===329?550:0;
  const gpuNeed=s.gpu?.id==="rtx4070s"?650:s.gpu?550:0;
  if(type==="good" && watts && gpuNeed && watts<gpuNeed){type="warn";msg=`● Fonte abaixo do recomendado (${gpuNeed} W)`;}
  if(type==="good" && state.budget && total()>state.budget){type="warn";msg="● Configuração acima do orçamento";}
  badge.className=`status ${type}`;badge.textContent=msg;
}

document.querySelector("#budget").addEventListener("input",e=>{state.budget=Number(e.target.value)||0;updateBudget();updateCompatibility();});
document.querySelector("#resetBtn").onclick=()=>{
  state.selected={};activeCategory="cpu";document.querySelector("#budget").value=6000;state.budget=6000;
  renderCategories();renderOptions();renderSummary();updateVisual();updateCompatibility();
  window.scrollTo({top:document.querySelector("#montador").offsetTop-70,behavior:"smooth"});
};
document.querySelector("#saveBtn").onclick=()=>{
  localStorage.setItem("site2-pc",JSON.stringify({selected:state.selected,budget:state.budget}));
  document.querySelector("#saveMessage").textContent="✓ Configuração salva neste navegador.";
};
document.querySelector("#shareBtn").onclick=async()=>{
  const text=`SITE2 — Meu PC | ${Object.values(state.selected).map(p=>p.name).join(", ")} | Total: ${money(total())}`;
  try{await navigator.clipboard.writeText(text);document.querySelector("#saveMessage").textContent="✓ Configuração copiada!";}
  catch{document.querySelector("#saveMessage").textContent=text;}
};

function loadSaved(){
  try{
    const saved=JSON.parse(localStorage.getItem("site2-pc"));
    if(saved?.selected){state.selected=saved.selected;state.budget=saved.budget||6000;document.querySelector("#budget").value=state.budget;}
  }catch{}
}
loadSaved();renderCategories();renderOptions();renderSummary();updateVisual();updateCompatibility();
